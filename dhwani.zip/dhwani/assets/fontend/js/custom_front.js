$(document).ready(function() {
	let $msg;
	$("#login_form").validate({
		rules: {
			email: {
				required:true,
				// email: true
			},
			password: "required",
		},
		messages: {
			email: {
				required: "Please enter your email",
				// email: "Please enter a valid email"
			},
			password: "Please enter your password",
		},
		submitHandler: function (form) {
			// form.submit();
			$.ajax({
				type: "POST",
				dataType: 'json',
				url: $(form).attr('action'),
				data: $(form).serialize(),
				success: function (msg) {
					if(msg==1){

						$msg = '<div id="msg" class="alert alert-success" >Login successful. <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="top: 10px; color: #155724;"> <span aria-hidden="true">&times;</span></button></div>';
						
						$('#msg').html($msg).show();
						
						setTimeout(() => {
							window.location.href = website_url + 'user/dashboard';
						}, 1000);
						
					}else if(msg == 0){
						$msg = '<div id="msg" class="alert" style="color: white; background: #ff8f7c; font-weight: bold;">Invalid credentials, please try again! <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="color: white; top: 10px"> <span aria-hidden="true">&times;</span></button></div>';

						$('#msg').html($msg).show();
						setTimeout(() => {
							$('#msg').fadeOut();
						}, 3000);

					}
				}
			});
			return false; // required to block normal submit since you used ajax 
		}
	});
});