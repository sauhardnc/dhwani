$(document).ready(function() {
	
	$('#example').DataTable();
	
	$('.status').on('click', function(e){
		
		let $this 		= $(this);
		let id 			= $(this).attr('data-id');
		let prevStatus 	= $(this).val();
		let status, confirmMsg;
		
		confirmMsg = 'Are your sure you want to change status?';
		if(prevStatus == 0){
			status = 1;
			// confirmMsg = 'Are your sure you want to unblock?';
		}else{
			status = 0;
			// confirmMsg = 'Are your sure you want to block?';
		}
		
		if(confirm(confirmMsg)){
			
			$.ajax({
				url: website_url + '/users/changeStatus',
				type: 'POST',
				data: {'id': id, 'status': status},
				dataType: 'JSON',
				success: function(msg) { 
					if(msg == 1){
						// alert('Status changed!');
						swal("Status changed!", "", "success");
						$this.val(status);
					}else{
						// alert('Something went wrong, please try again!');
						swal("Something went wrong.", "Please try again!", "error");
						if(prevStatus == 0){
							$this.prop('checked', false);
						}else{
							$this.prop('checked', true);
						}
					}
				}
			});
		}else{
			e.preventDefault();
		}
	});
	
});