﻿<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   
   require APPPATH . '/libraries/REST_Controller.php';
   // use Restserver\Libraries\REST_Controller;
     
class Dhwani_api extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
     
	# POST 
	# http://localhost/dhwani/api/dhwani_api/login
	# {"email": "superadmin@gmail.com", "password": "123456"}
	public function login_post(){
		
		$params = json_decode(file_get_contents('php://input'), TRUE);

		$paramArr = ['email', 'password'];
		
		if($paramArr !== array_keys($params)){
			
			$this->response(array('message' => 'Please provide correct parameters', 'status' => 0), REST_Controller::HTTP_BAD_REQUEST);
			
		}else if( !$params['email'] || !$params['password'] ){
			
			$this->response(['message' => 'Parameters can not be empty!', 'status' => 0], REST_Controller::HTTP_BAD_REQUEST);
		
		} else {
			
			$params['password'] = base64_encode($params['password']);
			$params['status'] = '1';
			
			$data['user'] = $this->db->get_where('users', $params)->row();
				
			if(!empty($data['user'])){
				$this->response(['message' => 'Query Successful', 'status' => 1, 'data' => $data], REST_Controller::HTTP_OK);
			}else{
				$this->response(['message' => 'Wrong Credentials!', 'status' => 0], REST_Controller::HTTP_BAD_REQUEST);
			}
		}	
	} 
	
	# GET 
	# http://localhost/dhwani/api/dhwani_api/get_states
	public function get_states_get(){
		
		$data['states'] = $this->db->where('status', '1')->get('state')->result();
			
		$this->response(['message' => 'Query Successful', 'status' => 1, 'data' => $data], REST_Controller::HTTP_OK);
				
	} 
	
	# POST 
	# http://localhost/dhwani/api/dhwani_api/get_state 
	# {"id": "1"}
	public function get_state_post(){
		
		$params = json_decode(file_get_contents('php://input'), TRUE);

		$paramArr = ['id'];
		
		if($paramArr !== array_keys($params)){
			
			$this->response(array('message' => 'Please provide correct parameters', 'status' => 0), REST_Controller::HTTP_BAD_REQUEST);
			
		}else if( !$params['id'] ){
			
			$this->response(['message' => 'All the parameters can not be empty!', 'status' => 0], REST_Controller::HTTP_BAD_REQUEST);
		
		} else {
			
			$params['status'] = '1';
			
			$data['state'] = $this->db->get_where('state', $params)->row();
				
			$this->response(['message' => 'Query Successful', 'status' => 1, 'data' => $data], REST_Controller::HTTP_OK);
		}	
	} 
	
	# GET 
	# http://localhost/dhwani/api/dhwani_api/get_districts
	public function get_districts_get(){
		
		$data['states'] = $this->db->where('status', '1')->get('district')->result();
			
		$this->response(['message' => 'Query Successful', 'status' => 1, 'data' => $data], REST_Controller::HTTP_OK);
				
	} 
	
	# POST 
	# http://localhost/dhwani/api/dhwani_api/get_districts 
	# {"id": "1", "state_id": "1"}
	# {"id": "1", "state_id": ""}
	# {"id": "", "state_id": "1"}
	public function get_districts_post(){
		
		$params = json_decode(file_get_contents('php://input'), TRUE);

		$paramArr = ['id', 'state_id'];
		
		if($paramArr !== array_keys($params)){
			
			$this->response(array('message' => 'Please provide correct parameters', 'status' => 0), REST_Controller::HTTP_BAD_REQUEST);
			
		} else if( !$params['id'] && !$params['state_id'] ){
			
			$this->response(['message' => 'All the parameters can not be empty!', 'status' => 0], REST_Controller::HTTP_BAD_REQUEST);
		
		} else {
			
			$this->db->select('*');
			
			if($params['id']){
				$this->db->where('id', $params['id']);
			}
			
			if($params['state_id']){
				$this->db->where('state_id', $params['state_id']);
			}
			$this->db->where('status', '1');
			
			$data['state'] = $this->db->from('district')->get()->result();
				
			$this->response(['message' => 'Query Successful', 'status' => 1, 'data' => $data], REST_Controller::HTTP_OK);
		}	
	}
	
	# GET 
	# http://localhost/dhwani/api/dhwani_api/get_child
	public function get_child_get(){
		
		$data['states'] = $this->db->where('status', '1')->get('child')->result();
			
		$this->response(['message' => 'Query Successful', 'status' => 1, 'data' => $data], REST_Controller::HTTP_OK);
				
	} 
	
	# POST 
	# http://localhost/dhwani/api/dhwani_api/get_child 
	# {"id": "1", "state_id": "1", "district_id": "1"}
	# {"id": "1", "state_id": "", "district_id": ""}
	# {"id": "", "state_id": "", "district_id": "1"}
	# {"id": "", "state_id": "1", "district_id": ""}
	# {"id": "1", "state_id": "1", "district_id": ""}
	# {"id": "1", "state_id": "", "district_id": "1"}
	# {"id": "", "state_id": "1", "district_id": "1"}
	public function get_child_post(){
		
		$params = json_decode(file_get_contents('php://input'), TRUE);

		$paramArr = ['id', 'state_id', 'district_id'];
		
		if($paramArr !== array_keys($params)){
			
			$this->response(array('message' => 'Please provide correct parameters', 'status' => 0), REST_Controller::HTTP_BAD_REQUEST);
			
		} else if( !$params['id'] && !$params['state_id'] && !$params['district_id'] ){
			
			$this->response(['message' => 'All the parameters can not be empty!', 'status' => 0], REST_Controller::HTTP_BAD_REQUEST);
		
		} else {
			
			$this->db->select('*');
			
			if($params['id']){
				$this->db->where('id', $params['id']);
			}
			
			if($params['state_id']){
				$this->db->where('state_id', $params['state_id']);
			}
			
			if($params['district_id']){
				$this->db->where('district_id', $params['district_id']);
			}
			
			$this->db->where('status', '1');
			
			$data['child'] = $this->db->from('child')->get()->result();
				
			$this->response(['message' => 'Query Successful', 'status' => 1, 'data' => $data], REST_Controller::HTTP_OK);
		}	
	}
}