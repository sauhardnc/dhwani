<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class District extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	private $menu_id;
	
	public function __construct() {
        
		parent::__construct();
		
		$this->menu_id = '5';
		
		if (!$this->session->userdata('is_user_login')) {
		
			redirect('/user');
		
		}elseif(!check_permission($this->session->userdata('role_id'), $this->menu_id, 'view_data')){
			
			redirect('/user');
		}
		
		$this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->model('District_model');
		$this->load->model('State_model');
	;	
    }
	
	public function index()
	{
		$data['page_title'] = 'District List';
		$data['menu_id'] 	= $this->menu_id;
		
		$data['dbValue'] = $this->District_model->get_districts();
		
		$this->load->view('user/vwDistrict', $data);
	}
	
	public function form($id = false)
	{
		if(!$id){
			$data['page_title'] = 'Add District';
		}else{
			$data['page_title'] = 'Edit District';
		}
		
		$data['menus'] = $this->District_model->get_menus();
		
		$data['id'] 			= '';
		$data['district_name']  = '';
		$data['state_id']		= '';
		$data['states']  		= $this->State_model->get_states();

		if($id){
			
			$dbValue = $this->District_model->get_district($id);
			
			if(!$dbValue){
				
				// page does not exist
				$this->session->set_flashdata('error', 'The requested page could not be found.');
				redirect('user/district');
			}
			
			$data['id'] 			= $id;
			$data['district_name']  = $dbValue->district_name;
			$data['state_id']  		= $dbValue->state_id;
		}
		
		$this->form_validation->set_rules('district_name', 'District', 'trim|required');
		$this->form_validation->set_rules('state_id', 'State', 'trim|required');
		
		if($this->form_validation->run() == false){	
			
			$this->load->view('user/vwDistrictForm', $data);
		
		}else{
			
			// echo '<pre>'; print_r($_POST); die;
			$save['id'] 		   	= $id;
			$save['district_name'] 	= $this->input->post('district_name');
			$save['state_id'] 	   	= $this->input->post('state_id');

			$dbId = $this->District_model->save_district($save);
			
			if($dbId){
				
				$this->session->set_flashdata('message', 'District saved successfully.');
			
			}else{
				
				$this->session->set_flashdata('message', 'Something went wrong, please try again!');
			}
			redirect('user/district');
		}
		// echo '<pre>'; print_r($data['permissions']); die;
	}
	
	public function delete_district($id){
		
		$del = $this->District_model->delete_district($id);
		
		if($del){
			$this->session->set_flashdata('message','Entry deleted successfully.');
		}else{
			$this->session->set_flashdata('error','Entry could not be deleted, please try again.');
		}
		redirect("user/district");	
	}
	
	public function get_district_by_states($state_id){
		
		$districts = $this->District_model->get_district_by_states($state_id);
		// print_r($districts);
		echo json_encode($districts);	
	}
}