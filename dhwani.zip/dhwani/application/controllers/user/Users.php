<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	private $menu_id;
	
	public function __construct() {
        
		parent::__construct();
		
		$this->menu_id = '1';
		
		if (!$this->session->userdata('is_user_login')) {
		
			redirect('/user');
		
		}elseif(!check_permission($this->session->userdata('role_id'), $this->menu_id, 'view_data')){
			
			redirect('/user');
		}
		
		$this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->model('User_model');
		$this->load->model('Role_model');
    } 
	 
	public function index()
	{
		$data['page_title'] = 'User List';
		$data['menu_id'] 	= $this->menu_id;
		
		$data['dbValue'] = $this->User_model->get_users();
		
		$this->load->view('user/vwUser', $data);
	}
	
	public function form($id = false)
	{	
		if(!$id){
			$data['page_title'] = 'Add User';
		}else{
			$data['page_title'] = 'Edit User';
		}
		
		$data['roles'] = $this->Role_model->get_roles();
		
		$data['id'] 			= '';
		$data['name'] 			= '';
		$data['email'] 			= '';
		$data['phone'] 			= '';
		$data['password'] 		= '';
		$data['role_id'] 		= '';
		
		if($id){
			
			$dbValue = $this->User_model->get_user($id);
			if(!$dbValue){
				
				//page does not exist
				$this->session->set_flashdata('error', 'The requested page could not be found.');
				redirect('user/users');
			}
			
			$data['id'] 			= $id;
			$data['name'] 			= $dbValue->name;
			$data['email'] 			= $dbValue->email;
			$data['phone'] 			= $dbValue->phone;
			$data['password'] 		= base64_decode($dbValue->password);
			$data['role_id'] 		= $dbValue->role_id;
		}
		
		$this->form_validation->set_rules('name', 'User Name', 'trim|required');
		$this->form_validation->set_rules('role_id', 'Role', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|callback_checkEmail');
		$this->form_validation->set_rules('phone', 'Phone', 'trim|required|is_numeric|callback_checkPhone');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		
		if($this->form_validation->run() == false){	
			
			$this->load->view('user/vwUserForm', $data);
		}else{
			
			// print_r($_POST); die;
			$save['id'] 			= $id;
			$save['name'] 			= $this->input->post('name');
			$save['email'] 			= $this->input->post('email');
			$save['phone'] 			= $this->input->post('phone');
			$save['password'] 		= base64_encode($this->input->post('password'));
			$save['role_id'] 		= $this->input->post('role_id');
			
			// print_r($save); die;
			$dbId = $this->User_model->save_user($save);
			if($dbId){
				
				$this->session->set_flashdata('message', 'User saved successfully.');
			}else{
				
				$this->session->set_flashdata('message', 'Something went wrong, please try again!');
			}
			redirect('user/users');
		}
		// echo '<pre>'; print_r($data['permissions']); die;
	}
	
	public function checkPhone($id){
		
		$id 	= $this->input->post('id');
		$phone 	= $this->input->post('phone');

		$num = $this->User_model->checkPhone($id, $phone);
		
		if ($num > 0) {
			
			$this->form_validation->set_message('checkPhone', 'Mobile No. already exists!');	
			return FALSE; 
		
		}else{
			return TRUE;
		}
	}
	
	public function checkEmail(){
		
		$id 	= $this->input->post('id');
		$email 	= $this->input->post('email');
		
		$num = $this->User_model->checkEmail($id, $email);
		
		if ($num > 0) {
			
			$this->form_validation->set_message('checkEmail', 'Email already exists!');	
			return FALSE; 
		
		}else{
			return TRUE;
		}
	}
	
	public function changeStatus(){
		
		$id 	= $this->input->post('id');
		$status = $this->input->post('status');
		
		$this->db->where('id', $id);
		$this->db->update('users', array('status' => $status));
		
		$num  = $this->db->affected_rows();
		
		if ($num > 0) {
			echo 1;
		}else{
			echo 0;
		}
	}
	
	public function delete_user($id){
		
		$del = $this->User_model->delete_user($id);
		
		if($del){
			$this->session->set_flashdata('message','Entry deleted successfully.');
		}else{
			$this->session->set_flashdata('error','Entry could not be deleted, please try again.');
		}
		redirect("user/users");	
	}
}