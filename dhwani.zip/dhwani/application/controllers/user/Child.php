<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Child extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	private $menu_id;
	
	public function __construct() {
        
		parent::__construct();
		
		$this->menu_id = '5';
		
		if (!$this->session->userdata('is_user_login')) {
		
			redirect('/user');
		
		}elseif(!check_permission($this->session->userdata('role_id'), $this->menu_id, 'view_data')){
			
			redirect('/user');
		}
		
		$this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->model('Child_model');
		$this->load->model('State_model');
		$this->load->model('District_model');
	;	
    }
	
	public function index()
	{
		$data['page_title'] = 'Child List';
		$data['menu_id'] 	= $this->menu_id;
		
		$data['dbValue'] = $this->Child_model->get_childs();
		
		$this->load->view('user/vwChild', $data);
	}
	
	public function form($id = false)
	{
		if(!$id){
			$data['page_title'] = 'Add Child';
		}else{
			$data['page_title'] = 'Edit Child';
		}
		
		$data['menus'] = $this->Child_model->get_menus();
		
		$data['id'] 			= '';
		$data['child_name']  	= '';
		$data['state_id']		= '';
		$data['district_id']	= '';
		
		$data['states']  		= $this->State_model->get_states();

		if($id){
			
			$dbValue = $this->Child_model->get_child($id);
			
			if(!$dbValue){
				
				// page does not exist
				$this->session->set_flashdata('error', 'The requested page could not be found.');
				redirect('user/child');
			}
			
			$data['id'] 			= $id;
			$data['child_name']  	= $dbValue->child_name;
			$data['state_id']  		= $dbValue->state_id;
			$data['district_id']  	= $dbValue->district_id;
			
			$data['districts']  	= $this->District_model->get_district_by_states($data['state_id']);
		}
		
		$this->form_validation->set_rules('child_name', 'Child', 'trim|required');
		$this->form_validation->set_rules('state_id', 'State', 'trim|required');
		$this->form_validation->set_rules('district_id', 'District', 'trim|required');
		
		if($this->form_validation->run() == false){	
			
			$this->load->view('user/vwChildForm', $data);
		
		}else{
			
			// echo '<pre>'; print_r($_POST); die;
			$save['id'] 		   	= $id;
			$save['child_name'] 	= $this->input->post('child_name');
			$save['state_id'] 	   	= $this->input->post('state_id');
			$save['district_id'] 	= $this->input->post('district_id');

			$dbId = $this->Child_model->save_child($save);
			
			if($dbId){
				
				$this->session->set_flashdata('message', 'Child saved successfully.');
			
			}else{
				
				$this->session->set_flashdata('message', 'Something went wrong, please try again!');
			}
			redirect('user/child');
		}
		// echo '<pre>'; print_r($data['permissions']); die;
	}
	
	public function delete_child($id){
		
		$del = $this->Child_model->delete_child($id);
		
		if($del){
			$this->session->set_flashdata('message','Entry deleted successfully.');
		}else{
			$this->session->set_flashdata('error','Entry could not be deleted, please try again.');
		}
		redirect("user/child");	
	}
	
}