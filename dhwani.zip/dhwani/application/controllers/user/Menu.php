<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	private $menu_id;
	
	public function __construct() {
       
		parent::__construct();
		
		$this->menu_id = '2';
		
		if (!$this->session->userdata('is_user_login')) {
		
			redirect('/user');
		
		}elseif(!check_permission($this->session->userdata('role_id'), $this->menu_id, 'view_data')){
			
			redirect('/user');
		}
		 
		$this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->model('Menu_model');
		
    }
	
	public function index()
	{
		$data['page_title'] = 'Menu List';
		$data['menu_id'] 	= $this->menu_id;
		
		$data['dbValue'] = $this->Menu_model->get_menus();
		
		$this->load->view('user/vwMenu', $data);
	}
	
	public function form($id = false)
	{
		if(!$id){
			$data['page_title'] = 'Add Menu';
		}else{
			$data['page_title'] = 'Edit Menu';
		}
		
		$data['id'] 		= '';
		$data['menu_name'] 	= '';
		$data['permission'] = array();
		
		if($id){
			
			$dbValue = $this->Menu_model->get_menu($id);
			
			if(!$dbValue){
				
				//page does not exist
				$this->session->set_flashdata('error', 'The requested page could not be found.');
				redirect('user/menu');
			}
			
			$data['id'] 		= $id;
			$data['menu_name'] 	= $dbValue->menu_name;
		}
		
		$this->form_validation->set_rules('menu_name', 'Menu', 'trim|required');
		
		if($this->form_validation->run() == false){	
			
			$this->load->view('user/vwMenuForm', $data);
		
		}else{
			
			$save['id'] = $id;
			$save['menu_name'] = $this->input->post('menu_name');
			
			$dbId = $this->Menu_model->save_menu($save);
			
			if($dbId){
				
				$this->session->set_flashdata('message', 'Menu saved successfully.');
			
			}else{
				
				$this->session->set_flashdata('message', 'Something went wrong, please try again!');
			}
			
			redirect('user/menu');
		}
	}
	
	public function delete_menu($id){
		
		$del = $this->Menu_model->delete_menu($id);
		
		if($del){
			$this->session->set_flashdata('message','Entry deleted successfully.');
		}else{
			$this->session->set_flashdata('error','Entry could not be deleted, please try again.');
		}
		
		redirect("user/menu");	
	}
	
}