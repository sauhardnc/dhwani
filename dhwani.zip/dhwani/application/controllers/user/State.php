<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class State extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	private $menu_id;
	
	public function __construct() {
        
		parent::__construct();
		
		$this->menu_id = '5';
		
		if (!$this->session->userdata('is_user_login')) {
		
			redirect('/user');
		
		}elseif(!check_permission($this->session->userdata('role_id'), $this->menu_id, 'view_data')){
			
			redirect('/user');
		}
		
		$this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->model('State_model');
	;	
    }
	
	public function index()
	{
		$data['page_title'] = 'State List';
		$data['menu_id'] 	= $this->menu_id;
		
		$data['dbValue'] = $this->State_model->get_states();
		
		$this->load->view('user/vwState', $data);
	}
	
	public function form($id = false)
	{
		if(!$id){
			$data['page_title'] = 'Add State';
		}else{
			$data['page_title'] = 'Edit State';
		}
		
		$data['menus'] = $this->State_model->get_menus();
		
		$data['id'] 		= '';
		$data['state_name'] = '';
		
		if($id){
			
			$dbValue = $this->State_model->get_state($id);
			
			if(!$dbValue){
				
				// page does not exist
				$this->session->set_flashdata('error', 'The requested page could not be found.');
				redirect('user/state');
			}
			
			$data['id'] 		= $id;
			$data['state_name'] = $dbValue->state_name;
		}
		
		$this->form_validation->set_rules('state_name', 'State', 'trim|required');
		
		if($this->form_validation->run() == false){	
			
			$this->load->view('user/vwStateForm', $data);
		
		}else{
			
			// echo '<pre>'; print_r($_POST); die;
			$save['id'] = $id;
			$save['state_name'] = $this->input->post('state_name');

			$dbId = $this->State_model->save_state($save);
			
			if($dbId){
				
				$this->session->set_flashdata('message', 'State saved successfully.');
			
			}else{
				
				$this->session->set_flashdata('message', 'Something went wrong, please try again!');
			}
			redirect('user/state');
		}
		// echo '<pre>'; print_r($data['permissions']); die;
	}
	
	public function delete_state($id){
		
		$del = $this->State_model->delete_state($id);
		
		if($del){
			$this->session->set_flashdata('message','Entry deleted successfully.');
		}else{
			$this->session->set_flashdata('error','Entry could not be deleted, please try again.');
		}
		redirect("user/state");	
	}
	
}