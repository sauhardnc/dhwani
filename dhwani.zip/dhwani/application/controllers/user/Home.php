<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
		$this->load->helper('form');
        $this->load->library('form_validation');
		
		$this->load->model('User_model');
    }
    
	public function index() {
        
		if ($this->session->userdata('is_user_login')) {
			
			$data['page_title'] = 'Home';
			$this->load->view('user/vwHome', $data);
        
		} else {
			
			$this->load->view('user/vwLogin');
        }
    }	
		
	public function registration() {
        
		if ($this->session->userdata('is_user_login')) {
            redirect('user/dashboard');
        } else {
            $this->load->view('user/registration_form');
        }
    }
	
    public function do_login(){
        
		if ($this->session->userdata('is_user_login')) {
            
			redirect('user/dashboard');
       
		} else {
            
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            
			if ($this->form_validation->run() == FALSE) {
				
				$data['error'] = validation_errors();
                $this->load->view('user/vwLogin',$data);
            } else {
				
				// print_r($_POST);
				$user     = $this->input->post('email');
				$password = $this->input->post('password');
				
				/* $salt = '5&JDDlwz%Rwh!t2Yg-Igae@QxPzFTSId';
                $enc_pass  = md5($salt.$password); */
                
				$enc_pass  = base64_encode($password);
				// echo $enc_pass;
                
				$sql = "SELECT * FROM users WHERE email = ? AND password = ? AND status = ?";
                
				$val = $this->db->query($sql,array($user ,$enc_pass, '1'))->row();
				// echo $this->db->last_query(); die;
               
			   if ($val) {
					//create session	
					$this->session->set_userdata(array(
						'id' => $val->id,
						'email' => $val->email,
						'name' => $val->name,
						'role_id' => $val->role_id,
						'is_user_login' => true
					));
					redirect('user/dashboard');
                } else {
                    $err['error'] = 'Username or Password incorrect';
                    $this->load->view('user/vwLogin', $err);
                }
            }
        }
    }
    
    public function logout(){

		$this->session->unset_userdata('id');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('name');
        $this->session->unset_userdata('role_id');   
        $this->session->unset_userdata('is_user_login');   
        
		$this->session->sess_destroy();
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        redirect('/user', 'refresh');
    }
}