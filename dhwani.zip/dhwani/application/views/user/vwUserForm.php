<?php
	$this->load->view('user/common/vwAdminHeader.php');

?>
<style>
	hr{
		margin-left: -20px;
    	margin-right: -20px;
	}
</style>

<div id="wrapper">
	<div class="main-content">
	
	<!--<nav class="nav_breadcrumb mb-3" aria-label="breadcrumb">
		<ol class="breadcrumb secondary-color">
		  <li class="breadcrumb-item"><a class="white-text" href="#">Home</a></li>
		  <li class="breadcrumb-item"><a class="white-text" href="#">Library</a></li>
		  <li class="breadcrumb-item active">Data</li>
		</ol>
	</nav>-->
	
		<!-- .row -->
		<div class="row small-spacing ">
			
			<div class="col-lg-12">
				<div class="box-content">
					<h4 class="box-title"><?php echo $page_title; ?>

					<hr>
					</h4>
					
					<?php $this->load->view('user/vwError'); ?>
					
					<form action="<?php echo base_url('user/users/form/').$id;?>" id="role_form" method="POST" enctype="multipart/form-data" autocomplete="off">
						
					<div class="row">
						<input type="hidden" id="user_id" name="id" value="<?php echo $id; ?>"/>
						<div class="form-group col-lg-6">
							<label for="role_id">Select Role<span class="text-danger">*</span></label>
							<select class="form-control select2_1" id="role_id" name="role_id">
								<option value="">--Select Role--</option>
								<?php foreach($roles as $role){ ?>
								<option value="<?php echo $role->id; ?>" <?php echo $role_id == $role->id ? 'selected' : ''; ?>><?php echo $role->role_name; ?></option>
								<?php } ?>
							</select>
						</div>

						<div class="form-group col-lg-6">
							<label for="name">Name</label>
							<input type="text" class="form-control" id="name" name="name" value="<?php echo set_value('name', $name);?>">
						</div>
						
						<div class="form-group col-lg-6">
							<label for="email">Email<span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="email" name="email" value="<?php echo set_value('email', $email);?>">
						</div>

						<div class="form-group col-lg-6">
							<label for="phone">Phone</label>
							<input type="text" class="form-control" id="phone" name="phone" value="<?php echo set_value('phone', $phone);?>">
						</div>

						<div class="form-group col-lg-6">
							<label for="password">Password<span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="password" name="password" value="<?php echo set_value('password', $password);?>">
						</div>

					</div>
								
					<button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Save</button>
					</form>
				</div>
			</div>

<?php
	$this->load->view('user/common/vwAdminFooter.php');
?>