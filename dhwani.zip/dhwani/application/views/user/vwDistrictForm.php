<?php
	$this->load->view('user/common/vwAdminHeader.php');

?>
<style>
	hr{
		margin-left: -20px;
    	margin-right: -20px;
	}
</style>

<div id="wrapper">
	<div class="main-content">
	
	<!--<nav class="nav_breadcrumb mb-3" aria-label="breadcrumb">
		<ol class="breadcrumb secondary-color">
		  <li class="breadcrumb-item"><a class="white-text" href="#">Home</a></li>
		  <li class="breadcrumb-item"><a class="white-text" href="#">Library</a></li>
		  <li class="breadcrumb-item active">Data</li>
		</ol>
	</nav>-->
		<!-- .row -->
		<div class="row small-spacing ">
			
			<div class="col-lg-12">
				<div class="box-content">
					<h4 class="box-title"><?php echo $page_title; ?>

					<hr>
					</h4>
					<?php $this->load->view('user/vwError'); ?>
					<!-- /.box-title -->
					<form method="POST" id="district_form" action="<?PHP echo base_url("user/district/form/$id"); ?>">
					<div class="row">
						
						<div class="form-group col-lg-6">
							<label for="district_name">District Name <span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="district_name" name="district_name" value="<?PHP echo set_value('district_name', $district_name);?>">
						</div>
						
						<div class="form-group col-lg-6">
							<label for="district_name">State Name <span class="text-danger">*</span></label>
							<select class="form-control" name="state_id">
								<option value="">--Select--</option>
								<?php foreach($states as $state): ?>
									<option value="<?php echo $state->id; ?>" <?php if($state->id == $state_id){echo 'selected'; } ?>><?php echo $state->state_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						
					</div>
					
					<button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Save</button>
					
					</form>
			
				</div>
			</div>

<?php
	$this->load->view('user/common/vwAdminFooter.php');
?>