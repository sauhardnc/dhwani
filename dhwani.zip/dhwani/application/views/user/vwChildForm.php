<?php
	$this->load->view('user/common/vwAdminHeader.php');

?>
<style>
	hr{
		margin-left: -20px;
    	margin-right: -20px;
	}
</style>

<div id="wrapper">
	<div class="main-content">
	
	<!--<nav class="nav_breadcrumb mb-3" aria-label="breadcrumb">
		<ol class="breadcrumb secondary-color">
		  <li class="breadcrumb-item"><a class="white-text" href="#">Home</a></li>
		  <li class="breadcrumb-item"><a class="white-text" href="#">Library</a></li>
		  <li class="breadcrumb-item active">Data</li>
		</ol>
	</nav>-->
		<!-- .row -->
		<div class="row small-spacing ">
			
			<div class="col-lg-12">
				<div class="box-content">
					<h4 class="box-title"><?php echo $page_title; ?>

					<hr>
					</h4>
					<?php $this->load->view('user/vwError'); ?>
					<!-- /.box-title -->
					<form method="POST" id="child_form" action="<?PHP echo base_url("user/child/form/$id"); ?>">
					<div class="row">
						
						<div class="form-group col-lg-6">
							<label for="child_name">Child Name <span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="child_name" name="child_name" value="<?PHP echo set_value('child_name', $child_name);?>">
						</div>
						
						<div class="form-group col-lg-6">
							<label for="child_name">State Name <span class="text-danger">*</span></label>
							<select class="form-control" name="state_id" id="state_id">
								<option value="">--Select--</option>
								<?php foreach($states as $state): ?>
									<option value="<?php echo $state->id; ?>" <?php if($state->id == $state_id){echo 'selected'; } ?>><?php echo $state->state_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						
					</div>
					
					<div class="row">
						
						<div class="form-group col-lg-6">
							<label for="child_name">District Name <span class="text-danger">*</span></label>
							<select class="form-control" name="district_id" id="district_id">
								<option value="">--Select--</option>
								<?php 
									if(!empty($districts)){
										foreach($districts as $district){ 
											echo '<option value="'.$district->id.'"'.(($district_id ==$district->id) ? 'selected="selected"' : "").'>'.$district->district_name.'</option>';
										}
									}
								?>
							</select>
						</div>
						
					</div>
					
					<button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Save</button>
					
					</form>
			
				</div>
			</div>
			
<?php
	$this->load->view('user/common/vwAdminFooter.php');
?>
<script>
	const $state_id 	= document.getElementById('state_id');
	const $district_id 	= document.getElementById('district_id');
	
	$state_id.addEventListener('change', getDistrict); 
	
	// const getDistrict = () => {
	function getDistrict(){
			
			let state_id = $state_id.value;

			if(state_id){
				
				fetch( website_url + '/district/get_district_by_states/' + state_id )
				.then((response) => {
					return response.json(); 
					console.log(response);
				})
				.then((data) => {
					
					let $added_option 	= $district_id.getElementsByTagName('option');
					
					let added_option_length = $added_option.length;
					if(added_option_length > 1){
						
						for(let i = 1; i < added_option_length; i++){
							
							$district_id.removeChild($added_option[1]);
						}
					}
					
					data.forEach( (item) => {
						
						childElement = document.createElement('option');
						childElement.value = item.id;
						
						appendChildElement = $district_id.appendChild(childElement);
						appendChildElement.innerHTML = item.district_name;
					});
					
				})
				.catch(err => alert(err));
			
			}
		
	}
</script>