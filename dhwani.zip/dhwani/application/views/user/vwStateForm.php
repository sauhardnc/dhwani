<?php
	$this->load->view('user/common/vwAdminHeader.php');

?>
<style>
	hr{
		margin-left: -20px;
    	margin-right: -20px;
	}
</style>

<div id="wrapper">
	<div class="main-content">
	
	<!--<nav class="nav_breadcrumb mb-3" aria-label="breadcrumb">
		<ol class="breadcrumb secondary-color">
		  <li class="breadcrumb-item"><a class="white-text" href="#">Home</a></li>
		  <li class="breadcrumb-item"><a class="white-text" href="#">Library</a></li>
		  <li class="breadcrumb-item active">Data</li>
		</ol>
	</nav>-->
		<!-- .row -->
		<div class="row small-spacing ">
			
			<div class="col-lg-12">
				<div class="box-content">
					<h4 class="box-title"><?php echo $page_title; ?>

					<hr>
					</h4>
					<?php $this->load->view('user/vwError'); ?>
					<!-- /.box-title -->
					<form method="POST" id="state_form" action="<?PHP echo base_url("user/state/form/$id"); ?>">
					<div class="row">
						
						<div class="form-group col-lg-6">
							<label for="state_name">State Name <span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="state_name" name="state_name" value="<?PHP echo set_value('state_name', $state_name);?>">
						</div>
						
					</div>
					
					<button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Save</button>
					
					</form>
			
				</div>
			</div>

<?php
	$this->load->view('user/common/vwAdminFooter.php');
?>