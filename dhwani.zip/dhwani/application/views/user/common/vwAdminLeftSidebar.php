<div class="main-menu">
	<header class="header">
		<a href="<?php echo base_url('user'); ?>" class="logo">AARA</a>
		<button type="button" class="button-close fa fa-times js__menu_close"></button>
	</header>
	<!-- /.header -->
	<div class="content">
		<?php 
			$current = 'current'; //class to show active menu
			$active = 'active'; //class to show submenu of active menu
		?>
		<div class="navigation">
			<ul class="menu js__accordion">
				<li class="<?php echo $page_title == 'Home' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/'); ?>"><i class="menu-icon fa fa-home"></i><span>Home</span></a>
				</li>
				
				<li class="<?php echo $page_title == 'Dashboard' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/dashboard'); ?>"><i class="menu-icon mdi mdi-view-dashboard"></i><span>Dashboard</span></a>
				</li>
				
				<?php if(check_permission($this->session->userdata('role_id'), '1', 'view_data')){ ?>
				<li class="<?php echo $page_title == 'User List' || $page_title == 'Add User' || $page_title == 'Edit User' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/users'); ?>"><i class="menu-icon fa fa-user"></i></i><span>User Management</span></a>
				</li>
				<?php } ?>
				<?php if(check_permission($this->session->userdata('role_id'), '2', 'view_data')){ ?>
				<li class="<?php echo $page_title == 'Menu List' || $page_title == 'Add Menu' || $page_title == 'Edit Menu' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/menu'); ?>"><i class="menu-icon fa fa-bars"></i><span>Menu Management</span></a>
				</li>
				<?php } ?>
				<?php if(check_permission($this->session->userdata('role_id'), '4', 'view_data')){ ?>
				<li class="<?php echo $page_title == 'Role List' || $page_title == 'Add Role' || $page_title == 'Edit Role' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/role'); ?>"><i class="menu-icon fa fa-user-plus"></i><span>Role Management</span></a>
				</li>
				
				<li class="<?php echo $page_title == 'State List' || $page_title == 'Add State' || $page_title == 'Edit State' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/state'); ?>"><i class="menu-icon fa fa-user-plus"></i><span>State Management</span></a>
				</li>
				
				<li class="<?php echo $page_title == 'District List' || $page_title == 'Add District' || $page_title == 'Edit District' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/district'); ?>"><i class="menu-icon fa fa-user-plus"></i><span>District Management</span></a>
				</li>
				
				<li class="<?php echo $page_title == 'Child List' || $page_title == 'Add Child' || $page_title == 'Edit Child' ? $current : ''; ?>">
					<a class="waves-effect" href="<?php echo base_url('user/child'); ?>"><i class="menu-icon fa fa-user-plus"></i><span>Child Management</span></a>
				</li>
				<?php } ?>
				<!--<li class="<?php echo $page_title == 'Subadmin List' || $page_title == 'Add Subadmin' || $page_title == 'Edit Subadmin' || $page_title == 'Role List' || $page_title == 'Add Role'|| $page_title == 'Edit Role' ? $current.' '.$active : ''; ?>">
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon fa fa-user-secret"></i><span>Subadmin</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li><a href="<?php echo base_url('user/role');?>">Role Management</a></li>
						<li><a href="<?php echo base_url('user/subadmin');?>">Subadmin Management</a></li>
					</ul>
				</li>-->
			</ul>
			<!-- /.menu js__accordion -->
		</div>
		<!-- /.navigation -->
	</div>
	<!-- /.content -->
</div>
<!-- /.main-menu -->
