<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     
    <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no" />
    <title>logisticwala</title>
    <meta name="author" content="Mannat Studio">     
    <meta name="description" content="Logzee is a Responsive HTML5 Template for Logistic and Cargo related services.">
    <meta name="keywords" content="Logzee, responsive, html5, business, cargo, chain supply, company, corporate, expedition, freight, logistics, packaging, services, shipping, transport, transportation, trucking, warehousing">
     
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo HTTP_IMAGES_PATH; ?>favicon.ico">

    <link href="<?php echo HTTP_CSS_PATH; ?>base.css" rel="stylesheet">
    <link href="<?php echo HTTP_CSS_PATH; ?>custom_front.css" rel="stylesheet">

    <!-- REVOLUTION STYLE SHEETS -->
    <link rel="stylesheet" type="text/css" href="<?php echo HTTP_PLUGINS_PATH; ?>rev-slider/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
    <link rel="stylesheet" type="text/css" href="<?php echo HTTP_PLUGINS_PATH; ?>rev-slider/revolution/fonts/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="<?php echo HTTP_PLUGINS_PATH; ?>rev-slider/revolution/css/settings.css">
    <link rel="stylesheet" type="text/css" href="<?php echo HTTP_PLUGINS_PATH; ?>rev-slider/revolution/css/layers.css">
    <link rel="stylesheet" type="text/css" href="<?php echo HTTP_PLUGINS_PATH; ?>rev-slider/revolution/css/navigation.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->		
	</head>
<body>

  <!-- Page loader Start -->
  <div id="pageloader">   
    <div class="loader-item">
      <div class="loader">
        <div class="spin"></div>
        <div class="bounce"></div>
      </div>
    </div>
  </div>
  <!-- Page loader End -->

  <header class="fixed-top header-fullpage top-transparent wow fadeInDown">
   <!----<div class="container top-bar-right">
      <div class="row align-items-center">
        <div class="col">
          <i class="icofont-google-map"></i>  777 , Tilak Nager , New Delhi , India
        </div>
        <div class="col-md-auto">

          <span class="mr-3"><i class="icofont-ui-touch-phone"></i> +00 41 895 785 6985</span>

          <span class="mr-3"><i class="icofont-ui-email"></i> Email Us</span>
          <!-- Topbar Language Dropdown Start -->
           <!-- <div class="dropdown d-inline-flex lang-toggle shadow-sm">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-hover="dropdown" data-animations="slideInUp slideInUp slideInUp slideInUp">
                <img src="<?php echo HTTP_IMAGES_PATH; ?>us.svg" alt="" class="dropdown-item-icon"> 
                <span class="d-inline-block d-lg-none">US</span>
                <span class="d-none d-lg-inline-block">United States</span> <i class="icofont-rounded-down"></i>
              </a>
              <div class="dropdown-menu dropdownhover-bottom dropdown-menu-right" role="menu">
                <a class="dropdown-item active" href="#">English</a>
                <a class="dropdown-item" href="#">Deutsch</a>
                <a class="dropdown-item" href="#">Español&lrm;</a>
              </div>
            </div> -->           
            <!-- Topbar Language Dropdown End -->        
        </div>
      </div> 
    </div> 
    
    <!-- Main Navigation Start -->
    <nav class="navbar navbar-expand-lg bg-transparent">
      <div class="container p-0 text-nowrap">
        <div class="d-flex align-items-center w-100 col pl-0">
          <a class="navbar-brand rounded-bottom light-bg" href="index.html">
            <img src="<?php echo HTTP_IMAGES_PATH; ?>logo1.png" alt=""><!--logo_footer.png-->
          </a> 
        </div>
        <!-- Topbar Request Quote Start -->
        <div class="d-inline-flex request-btn order-lg-last col p-0"> 
          <a class="nav-link mr-2 ml-auto" href="#" id="search_home"><i class="icofont-search"></i></a>
           
		  <a class="btn-theme icon-left bg-custom-blue no-shadow align-self-center" href="#" role="button" data-toggle="modal" data-target="#request_popup"><i class="icofont-page"></i> <span class="d-none d-sm-inline-block"> Request Quote</span></a> &nbsp;
		  
		  <?php if ($this->session->userdata('is_user_login') && ($this->session->userdata('user_type') == 'vendor' || $this->session->userdata('user_type') == 'customer')) { ?>
			<a class="btn-theme icon-left bg-custom-blue no-shadow align-self-center" href="<?php echo base_url('user/home/logout'); ?>" style="padding: 0.6rem 0.8rem;"><i class="icofont-page"></i> <span class="d-none d-sm-inline-block"> Logout</span></a>
		<?php }else{ ?>
		  <a class="btn-theme icon-left bg-custom-blue no-shadow align-self-center" href="#" role="button" data-toggle="modal" data-target="#login_modal"><i class="icofont-page"></i> <span class="d-none d-sm-inline-block"> Login</span></a>
		<?php } ?>
          <!-- Toggle Button Start -->
          <button class="navbar-toggler x collapsed" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
          <!-- Toggle Button End -->  
        </div>
        <!-- Topbar Request Quote End -->

        <div class="collapse navbar-collapse" id="navbarCollapse" data-hover="dropdown" data-animations="slideInUp slideInUp slideInUp slideInUp">
          <ul class="navbar-nav ml-auto">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle-mob" href="index.html" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Home <i class=""></i></a>                
               <!--- <ul class="dropdown-menu" aria-labelledby="dropdown03">
                  <li><a class="dropdown-item" href="index.html">Home Layout 1</a></li>
                      <li><a class="dropdown-item" href="index-2.html">Home Layout 2</a></li>
                      <li><a class="dropdown-item" href="index-3.html">Home Layout 3</a></li>
                      <li><a class="dropdown-item" href="index-4.html">Home Layout 4</a></li>
                      <li><a class="dropdown-item" href="index-5.html">Home Layout 5</a></li>
                      <li class="dropdown">
                      <a class="dropdown-toggle-mob dropdown-item" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Third Level Menu <i class="icofont-rounded-right float-right"></i></a>
                      <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a href="#" class="dropdown-item">Action</a></li>
                        <li><a href="#" class="dropdown-item">Another action</a></li>
                        <li><a href="#" class="dropdown-item">Something else here</a></li>
                      </ul>
                  </li>
                </ul>--->
              </li>
				 <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle-mob" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">TRANSPORTATING<!--Pages--> <i class="icofont-rounded-down"></i></a>
                <ul class="dropdown-menu">                  
                  <li><a class="dropdown-item" href="#">Road</a></li>
                  <li><a class="dropdown-item" href="#">Train</a></li>                  
                  <li><a class="dropdown-item" href="#">Air</a></li>
                  <li><a class="dropdown-item" href="#">Domestic Couries</a></li>
                  <li><a class="dropdown-item" href="#">Dedicated vehicle monthly</a></li>                  
                </ul>
              </li>
				
				
				
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle-mob" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Worehousing<!--Pages--> <i class="icofont-rounded-down"></i></a>
                <ul class="dropdown-menu">                  
                  <li><a class="dropdown-item" href="#">3PL/4PL</a></li>
                  <li><a class="dropdown-item" href="#">Purchase</a></li>                  
                  <li><a class="dropdown-item" href="#">Rental</a></li>                 
                </ul>
              </li>
             
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle-mob" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Global Logistics
				<i class="icofont-rounded-down"></i></a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="#">Air Cargo </a></li>
                  <li><a class="dropdown-item" href="#">Sea Shipping</a></li>
                  <li><a class="dropdown-item" href="#">International Couries</a></li>
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle-mob" href="index.html" id="blog-menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Elite Services<!--Blog--> <i class="icofont-rounded-down"></i></a>
                
                <ul class="dropdown-menu" aria-labelledby="blog-menu">
                  <li><a class="dropdown-item" href="#">Movers & packers</a></li>
                  <li><a class="dropdown-item" href="#">Critical Management Services</a></li>
                  <li><a class="dropdown-item" href="#">Project Management Services</a></li>
                  <li><a class="dropdown-item" href="#">Logisties Advertisement Services</a></li>
                  <li><a class="dropdown-item" href="#">Cold Chain</a></li>
                  <li><a class="dropdown-item" href="#">Warehousing Infra</a></li>
                </ul>
              </li>
             <!-- <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle-mob" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Contact <i class="icofont-rounded-down"></i></a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="contact-us.html">Contact Us</a></li>
                  <li><a class="dropdown-item" href="contact-us-option.html">Contact Us Option</a></li>
                </ul>
              </li>-->
          </ul>
          <!-- Main Navigation End -->
        </div>
      </div>
    </nav>
    <!-- Main Navigation End -->
  </header>