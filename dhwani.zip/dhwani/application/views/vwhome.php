<?php
	$this->load->view('vwheader.php');
	$this->load->view('vwhomeslider.php');
?>


  <!-- Main Body Content Start -->
  <main id="body-content" style="overflow-y: inherit;">
    <!-- Welcome To Cargo Start -->
    <section class="wide-tb-100 p-0 bg-sky-blue home-welcome">
      <div class="container">
        <div class="row">

          <!-- Icon Box 1 -->
          <div class="col-md-4">   
            <a href="service-details.html">           
              <div class="icon-box-with-img bg-navy-blue">
                <img src="<?php echo HTTP_IMAGES_PATH; ?>icon-box-img-1.jpg" alt="">
                <div class="text">
                  Freight Forwarding
                </div>
              </div>  
            </a>            
          </div>
          <!-- Icon Box 1 -->

          <!-- Icon Box 1 -->
          <div class="col-md-4"> 
            <a href="service-details.html">             
              <div class="icon-box-with-img bg-navy-blue">
                <img src="<?php echo HTTP_IMAGES_PATH; ?>icon-box-img-2.jpg" alt="">
                <div class="text">
                  Road Freight
                </div>
              </div>   
            </a>           
          </div>
          <!-- Icon Box 1 -->

          <!-- Icon Box 1 -->
          <div class="col-md-4">   
            <a href="service-details.html">           
              <div class="icon-box-with-img bg-navy-blue">
                <img src="<?php echo HTTP_IMAGES_PATH; ?>icon-box-img-3.jpg" alt="">
                <div class="text">
                  Car transportation
                </div>
              </div>              
            </a>
          </div>
          <!-- Icon Box 1 -->

        </div>
      </div>
    </section>
    <!-- Welcome To Cargo End -->

    <!-- What Makes Us Special Start -->
    <section class="bg-sky-blue wide-tb-100">
      <div class="container pos-rel">
        <div class="row">
          <div class="img-business-man">
            <img src="<?php echo HTTP_IMAGES_PATH; ?>courier-man.png" alt="">
          </div>
          <!-- Heading Main -->
          <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
            <h1 class="heading-main">
              <span>Our Goodness</span>
              What Makes Us Special
            </h1>
          </div>
          <!-- Heading Main -->
          <div class="col-md-6 ml-auto">
              <div class="row">
                <!-- Icon Box 2 -->
                <div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">              
                  <div class="icon-box-3 mb-5 bg-sky-blue">
                    <div class="media">
                        <div class="service-icon mr-5">
                            <i class="icofont-box"></i>
                        </div>
                        <div class="service-inner-content media-body">
                            <h4 class="h4-md">Packaging and Storage</h4>
                            <p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.</p>
                        </div>
                    </div>
                  </div>              
                </div>
                <!-- Icon Box -->

                <!-- Icon Box 2 -->
                <div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">              
                  <div class="icon-box-3 mb-5 bg-sky-blue">
                    <div class="media">
                        <div class="service-icon mr-5">
                            <i class="icofont-shield"></i>
                        </div>
                        <div class="service-inner-content media-body">
                            <h4 class="h4-md">Safety & Quality</h4>
                            <p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.</p>
                        </div>
                    </div>
                  </div>              
                </div>
                <!-- Icon Box -->

                <!-- Icon Box 2 -->
                <div class="col-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.4s">              
                  <div class="icon-box-3 bg-sky-blue">
                    <div class="media">
                        <div class="service-icon mr-5">
                            <i class="icofont-tree-alt"></i>
                        </div>
                        <div class="service-inner-content media-body">
                            <h4 class="h4-md">Care for Environment</h4>
                            <p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae. Praesent pellentesque diam vitae nibh aliquam faucibus.</p>
                        </div>
                    </div>
                  </div>              
                </div>
                <!-- Icon Box -->
              </div>
          </div>
        </div>
        
      </div>
    </section>
    <!-- What Makes Us Special End -->

    <!-- About Us Start -->
    <section class="bg-white wide-tb-100 mb-spacer-md">
      <div class="container">          
        <!-- Heading Main -->
        <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
          <h1 class="heading-main">
            <span>Who we are</span>
            About Us
          </h1>
        </div>
        <!-- Heading Main -->

        <div class="row wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
            <div class="col-lg-8">
              <!-- Blockquote Start -->
              <div class="about-bg bg-sky-blue">
                <div class="row d-flex align-items-end">                    
                  <div class="col-12 pt-5 order-sm-12 col-sm-6">
                    <blockquote class="blockquote style-one">
                      <p class="mb-0">There is no design without discipline. There is no discipline without intelligence.</p>
                      <footer class="blockquote-footer"><cite title="Source Title">Steven Snell Google</cite></footer>
                    </blockquote>
                  </div>
                  <div class="col-12 mb-0 order-sm-1 col-sm-6">
                    <img src="<?php echo HTTP_IMAGES_PATH; ?>about_img.png" alt="">
                  </div>
                </div>
              </div>
              <!-- Blockquote Start -->
            </div>

            <!-- Spacer For Medium -->
            <div class="w-100 d-none d-sm-block d-lg-none spacer-60"></div>
            <!-- Spacer For Medium -->

            <!-- Right Text Start -->
            <div class="col-lg-4">
              <div class="align-self-stretch h-100 align-items-center d-flex bg-with-text">
                  Whether you require distribution or fulfillment, defined freight forwarding, or a complete supply chain solution, we are here for you.
              </div>
            </div>
            <!-- Right Text Start -->
        </div>


        <div class="row text-center mobile-100">
          <div class="col-sm-12">
            <div class="spacer-50"></div>
            <a href="#" class="btn-theme bg-custom-blue">Request Quote <i class="icofont-rounded-right"></i></a>
            <a href="#" class="ml-5 link-oragne icon-left play-video"><i class="icofont-play"></i> Watch Our Short Video</a>
          </div>
          <div class="video-box">
              <!-- close-video -->
              <div class="close-video">
                  <i class="fa fa-times"></i>
              </div><!-- /close-video -->
          </div><!-- /video-box -->
        </div>
        </div>
    </section>
    <!-- About Us End -->

    <!-- Counter Start -->
    <section class="wide-tb-100 bg-scroll counter-bg pos-rel">
      <div class="bg-overlay blue opacity-50"></div>
      <div class="container">
        <div class="row">
            <!-- Counter Col Start -->
            <div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
              <p><i class="icofont-google-map"></i></p>
              <span class="counter">15</span>
              <div>
                Our Locations
              </div>
            </div>
            <!-- Counter Col End -->

            <!-- Counter Col Start -->
            <div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
              <p><i class="icofont-globe"></i></p>
              <span class="counter">110</span>
              <span>+</span>
              <div>
                Clients Worldwide
              </div>
            </div>
            <!-- Counter Col End -->

            <!-- Spacer For Medium -->
            <div class="w-100 d-none d-sm-block d-lg-none spacer-60"></div>
            <!-- Spacer For Medium -->

            <!-- Counter Col Start -->
            <div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInRight" data-wow-duration="0" data-wow-delay="0">
              <p><i class="icofont-vehicle-delivery-van"></i></p>
             <span class="counter">240</span>
              <span>+</span>
              <div>
                Owned Vehicles
              </div>
            </div>
            <!-- Counter Col End -->

            <!-- Counter Col Start -->
            <div class="col counter-style-1 col-6 col-lg-3 col-sm-6 wow fadeInRight" data-wow-duration="0" data-wow-delay="0s">
              <p><i class="icofont-umbrella-alt"></i></p>
              <span class="counter">2340</span>
              <div>
                Tonnes Transported
              </div>
            </div>
            <!-- Counter Col End -->
        </div>
      </div>        
    </section>
    <!-- Counter End -->

    <!-- Tracking Your Freight Start -->
    <section class="wide-tb-100 pb-0">
      <div class="container">
        <div class="row">              
            <div class="col-lg-7 ml-lg-auto pos-rel col-md-12">               

              <!-- Heading Main -->
              <h1 class="heading-main text-left">
                <span>get updates</span>
                Tracking Your Freight
              </h1>
              <!-- Heading Main -->
              
              <!-- Tracking Form -->
              <form class="form-inline tracking">
                <input type="text" class="form-control mb-2 mr-sm-2 col" placeholder="Enter order number">
                <button type="submit" class="btn btn-theme bg-custom-blue mb-2 ml-3">Check Now <i class="icofont-rounded-right"></i></button>
              </form>
              <!-- Tracking Form -->

              <!-- Forklift Image -->
              <div class="forklift-image wow slideInLeft" data-wow-duration="0" data-wow-delay="0s">
                <img src="<?php echo HTTP_IMAGES_PATH; ?>forklift_Image.png" alt="">
              </div>
              <!-- Forklift Image -->

            </div>              
        </div>
      </div>        
    </section>
    <!-- Tracking Your Freight End -->

    <!-- Our Team Start -->
    <section class="bg-white wide-tb-100 mb-spacer-md">
      <div class="container">          
        <!-- Heading Main -->
        <div class="col-sm-12">
          <h1 class="heading-main">
            <span>Face Behind Logzee</span>
            Our Team
          </h1>
        </div>
        <!-- Heading Main -->

        <div class="row pb-5">
          <!-- Team Column One -->
          <div class="col-12 col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
            <div class="team-section-one">
              <img src="<?php echo HTTP_IMAGES_PATH; ?>team/team-1.jpg" alt="" class="rounded-circle">
              <h4 class="h4-md txt-blue">John Morise</h4>
              <h5 class="h5-md txt-ligt-gray">Founder</h5>
            </div>            
          </div>
          <!-- Team Column One -->

          <!-- Team Column One -->
          <div class="col-12 col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.1s">
            <div class="team-section-one">
              <img src="<?php echo HTTP_IMAGES_PATH; ?>team/team-2.jpg" alt="" class="rounded-circle">
              <h4 class="h4-md txt-blue">Kevin Mash</h4>
              <h5 class="h5-md txt-ligt-gray">Head Operational</h5>
            </div>            
          </div>
          <!-- Team Column One -->

          <!-- Spacer For Medium -->
          <div class="w-100 d-none d-sm-block d-lg-none spacer-60"></div>
          <!-- Spacer For Medium -->

          <!-- Team Column One -->
          <div class="col-12 col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
            <div class="team-section-one">
              <img src="<?php echo HTTP_IMAGES_PATH; ?>team/team-3.jpg" alt="" class="rounded-circle">
              <h4 class="h4-md txt-blue">Mike Douglos</h4>
              <h5 class="h5-md txt-ligt-gray">Team Lead Support</h5>
            </div>            
          </div>
          <!-- Team Column One -->

          <!-- Team Column One -->
          <div class="col-12 col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.3s">
            <div class="team-section-one">
              <img src="<?php echo HTTP_IMAGES_PATH; ?>team/team-4.jpg" alt="" class="rounded-circle">
              <h4 class="h4-md txt-blue">Jeff Fashkin</h4>
              <h5 class="h5-md txt-ligt-gray">Head Operational</h5>
            </div>            
          </div>
          <!-- Team Column One -->
        </div>

        <div class="row text-center mt-5 wow fadeInDown" data-wow-duration="0" data-wow-delay="0.5s">
          <div class="col-sm-8 offset-md-2">
            <h3 class="h3-xl">We Are Hiring! <span class="lead">Become part of our talented team</span></h3>
            <p class="mt-4">Vivamus imperdiet pulvinar risus, at posuere justo scelerisque sed. Vestibulum ante 
            ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae.</p>
            <a href="#" class="btn-theme bg-custom-blue mt-2">Join Our Team <i class="icofont-rounded-right"></i></a>
          </div>
        </div>
    </div>
    </section>
    <!-- Our Team End -->

    <!-- Free Quote Start -->
    <section class="wide-tb-100 bg-fixed free-quote free-quote-alt pb-0">
      <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-7">
              <div class="free-quote-form">
                <!-- Heading Main -->
                <h1 class="heading-main mb-4">
                  <span>Request a </span>
                  Free Quote
                </h1>
                <!-- Heading Main -->

                <!-- Free Quote From -->
                <form action="#" method="post" novalidate="novalidate" class="col rounded-field">
                    <div class="form-row mb-4">
                        <input type="text" name="name" class="form-control" placeholder="Your Name">
                    </div>
                    <div class="form-row mb-4">
                        <input type="text" name="email" class="form-control" placeholder="Email">
                    </div>
                    <div class="form-row mb-4">
                        <select title="Please choose a package" required="" name="package" class="custom-select" aria-required="true" aria-invalid="false">
                            <option value="">Transport Type</option>
                            <option value="Type 1">Type 1</option>
                            <option value="Type 2">Type 2</option>
                            <option value="Type 3">Type 3</option>
                            <option value="Type 4">Type 4</option>
                        </select>
                    </div>
                    <div class="form-row mb-4">
                        <select title="Please choose a package" required="" name="package" class="custom-select" aria-required="true" aria-invalid="false">
                            <option value="">Type of freight</option>
                            <option value="Type 1">Type 1</option>
                            <option value="Type 2">Type 2</option>
                            <option value="Type 3">Type 3</option>
                            <option value="Type 4">Type 4</option>
                        </select>
                    </div>
                    <div class="form-row mb-4">
                      <textarea rows="7" placeholder="Message" class="form-control"></textarea>
                    </div>
                    <div class="form-row text-center">
                        <button type="submit" class="form-btn mx-auto btn-theme bg-custom-blue">Submit Now <i class="icofont-rounded-right"></i></button>
                    </div>
                </form>
                <!-- Free Quote From -->
              </div>
            </div>
        </div>
    </div>
    </section>
    <!-- Free Quote End -->

    <!-- Client Testimonials Start -->
   
    <!-- Client Testimonials End -->

    <!-- Callout Start -->
    <section class="wide-tb-80 bg-custom-blue callout-style-1 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s" style="opacity: 0.8">
      <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4 col-md-12 mb-0">
              <h4 class="h4-xl">Interested in working with Logzee?</h4>
            </div>
            <div class="col">
              <div class="center-text">
                We don’t just manage suppliers, we micro-manage them. We have a consultative, personalized approach
              </div>
            </div>
            <div class="col-sm-auto">
              <a href="#" class="btn-theme bg-white light">Get In Touch <i class="icofont-rounded-right"></i></a>
            </div>
        </div>
      </div>
    </section>
	 <section class="wide-tb-100">
      <div class="container">
        <div class="row">
            <!-- Heading Main -->
            <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
              <h1 class="heading-main">
                <span>What Our</span>
                Customers Saying
              </h1>
            </div>
            <!-- Heading Main -->
            <div class="col-sm-12">
              <div class="owl-carousel owl-theme" id="home-client-testimonials">

                <!-- Client Testimonials Slider Item -->
                <div class="item">
                  <div class="client-testimonial bg-wave">
                    <div class="media">
                        <div class="client-testimonial-icon rounded-circle bg-navy-blue">
                            <img src="<?php echo HTTP_IMAGES_PATH; ?>team_1.jpg" alt="">
                        </div>
                        <div class="client-inner-content media-body">
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Aliquam gravida, urna quis ornare imperdiet, </p>
                            <footer class="blockquote-footer"><cite title="Source Title">John Gerry  Design Hunt</cite></footer>
                        </div>
                    </div>
                  </div>
                </div>
                <!-- Client Testimonials Slider Item -->

                <!-- Client Testimonials Slider Item -->
                <div class="item">
                  <div class="client-testimonial bg-wave">
                    <div class="media">
                        <div class="client-testimonial-icon rounded-circle bg-navy-blue">
                            <img src="<?php echo HTTP_IMAGES_PATH; ?>team_2.jpg" alt="">
                        </div>
                        <div class="client-inner-content media-body">
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Aliquam gravida, urna quis ornare imperdiet, </p>
                            <footer class="blockquote-footer"><cite title="Source Title">John Gerry  Design Hunt</cite></footer>
                        </div>
                    </div>
                  </div>
                </div>
                <!-- Client Testimonials Slider Item -->

                <!-- Client Testimonials Slider Item -->
                <div class="item">
                  <div class="client-testimonial bg-wave">
                    <div class="media">
                        <div class="client-testimonial-icon rounded-circle bg-navy-blue">
                            <img src="<?php echo HTTP_IMAGES_PATH; ?>team_3.jpg" alt="">
                        </div>
                        <div class="client-inner-content media-body">
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Aliquam gravida, urna quis ornare imperdiet, </p>
                            <footer class="blockquote-footer"><cite title="Source Title">John Gerry  Design Hunt</cite></footer>
                        </div>
                    </div>
                  </div>
                </div>
                <!-- Client Testimonials Slider Item -->

              </div>
            </div>
        </div>
    </div>
    </section>
    <!-- Callout End -->

    <!-- Company News Start -->
   <!------ <section class="wide-tb-100">
      <div class="container">
        <div class="row">
            <!-- Heading Main -->
            <!----<div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
              <h1 class="heading-main">
                <span>COMPANY'S NEWS</span>
                Recent Posts
              </h1>
            </div>
            <!-- Heading Main -->

            <!-- Blog Items -->
           <!----- <div class="col-sm-12 col-md-4 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0.1s">
                <div class="blog-warp">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>blog_img_1.jpg" alt="" class="rounded">
                  <div class="meta-box"><a href="#">Business</a> <span>/</span>    September 28, 2018</div>
                  <h4 class="h4-md mb-3"><a href="#">Freight Payment and Auditing Services</a></h4>
                  <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantiumg</p>
                </div>
            </div>
            <!-- Blog Items -->

            <!-- Blog Items -->
           <!---- <div class="col-sm-12 col-md-4 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.1s">
                <div class="blog-warp">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>blog_img_2.jpg" alt="" class="rounded">
                  <div class="meta-box"><a href="#">Business</a> <span>/</span>    September 28, 2018</div>
                  <h4 class="h4-md mb-3"><a href="#">Freight Payment and Auditing Services</a></h4>
                  <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantiumg</p>
                </div>
            </div>
            <!-- Blog Items -->

            <!-- Blog Items -->
          <!----  <div class="col-sm-12 col-md-4 wow fadeInRight" data-wow-duration="0" data-wow-delay="0.1s">
                <div class="blog-warp">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>blog_img_3.jpg" alt="" class="rounded">
                  <div class="meta-box"><a href="#">Business</a> <span>/</span>    September 28, 2018</div>
                  <h4 class="h4-md mb-3"><a href="#">Freight Payment and Auditing Services</a></h4>
                  <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantiumg</p>
                </div>
            </div>
            <!-- Blog Items -->


       <!---- </div>
    </div>
    </section>
    <!-- Company News End -->

    <!-- Clients Start -->
    <section class="wide-tb-100 bg-fixed clients-bg pos-rel">
      <div class="bg-overlay blue opacity-80"></div>
      <div class="container">
        <div class="row">
            <!-- Heading Main -->
            <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
              <h1 class="heading-main">
                <span>SOME OF OUR</span>
                Clients
              </h1>
            </div>
            <!-- Heading Main -->

            <div class="col-sm-12 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.2s">
              <div class="owl-carousel owl-theme" id="home-clients">

                <!-- Client Logo -->
                <div class="item">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>clients/client1.png" alt="">
                </div>
                <!-- Client Logo -->

                <!-- Client Logo -->
                <div class="item">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>clients/client2.png" alt="">
                </div>
                <!-- Client Logo -->

                <!-- Client Logo -->
                <div class="item">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>clients/client3.png" alt="">
                </div>
                <!-- Client Logo -->

                <!-- Client Logo -->
                <div class="item">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>clients/client4.png" alt="">
                </div>
                <!-- Client Logo -->

                <!-- Client Logo -->
                <div class="item">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>clients/client5.png" alt="">
                </div>
                <!-- Client Logo -->

                <!-- Client Logo -->
                <div class="item">
                  <img src="<?php echo HTTP_IMAGES_PATH; ?>clients/client6.png" alt="">
                </div>
                <!-- Client Logo -->

              </div>
            </div>
        </div>
      </div>        
    </section>
    <!-- Clients End -->

    <!-- Google Map Start -->
    <section class="map-bg">
     <!--<div class="contact-details row d-flex">
        <div class="col">
          <h4>Germany</h4>
          <p><i class="icofont-phone"></i> +1 (408) 786 - 5117</p>
          <div class="text-nowrap"><i class="icofont-email"></i> <a href="#">germany@logzee.com</a></div>
        </div>
        <div class="col">
          <h4>Spain</h4>
          <p><i class="icofont-phone"></i> +1 (408) 786 - 5117</p>
          <div class="text-nowrap"><i class="icofont-email"></i> <a href="#">spain@logzee.com</a></div>
        </div>
      </div>-->
      <div id="map-holder" class="pos-rel">
          <div id="map_extended">
              <p>This will be replaced with the Google Map.</p>
          </div>
      </div>
      <!-- Google Map Start -->
    </section>     
  </main>
  <!-- Main Body Content Start -->
<?php
	$this->load->view('vwfooter.php');
?>