<?php
Class Menu_model extends CI_Model
{
	
	function get_menus(){
		
		$query = $this->db->order_by('id', 'ASC')->get_where('menu_master', array('status' => '1'))->result();
		// echo $this->db->last_query(); die;
		return $query;
    }
	
	function save_menu($save){
	   
		if ($save['id'] != ""){
			
			$this->db->where('id', $save['id']);
			$this->db->update('menu_master', $save);

			$id	= $save['id'];
		}
		else{
			
			$this->db->insert('menu_master', $save);
			$id	= $this->db->insert_id();
		}
		return $id;
	}
	
	function get_menu($id){
		
		$query = $this->db->get_where('menu_master', array('id'=>$id))->row();
		return $query;
    }
	
	function delete_menu($id){
		
		return $this->db->where('id', $id)->delete('menu_master');
	}
	
}