<?php
Class District_model extends CI_Model
{
	function get_districts(){
		
		$query = $this->db->order_by('id', 'DESC')->get_where('district', array('status' => '1'))->result();
		// echo $this->db->last_query(); die;
		return $query;
    }
	
	function get_menus(){
		
		$query = $this->db->order_by('id', 'ASC')->get_where('menu_master', array('status' => '1'))->result();
		// echo $this->db->last_query(); die;
		return $query;
    }
	
	function save_district($save){
	   
		if ($save['id'] != ""){
			
			$this->db->where('id', $save['id']);
			$this->db->update('district', $save);

			$id	= $save['id'];
		}
		else{
			
			$this->db->insert('district', $save);
			$id	= $this->db->insert_id();
		}
		return $id;
	}
	
	function get_district($id){
		
		$query = $this->db->get_where('district', array('id'=>$id))->row();
		return $query;
    }
	
	function get_district_by_states($state_id){
		
		$query = $this->db->get_where('district', array('state_id'=>$state_id))->result();
		return $query;
    }
	
	function delete_district($id){
		
		return $this->db->where('id', $id)->delete('district');
	}
}