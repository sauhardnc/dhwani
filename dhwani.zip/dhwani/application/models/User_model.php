<?php
Class User_model extends CI_Model
{
	function get_users(){
		
		$this->db->order_by('id', 'DESC');
		$this->db->select('users.*, role.role_name');
		$this->db->join('role', 'users.role_id = role.id', 'INNER');
		$query = $this->db->from('users')->get()->result();
		// echo $this->db->last_query(); die;
		return $query;
    }
	
	function save_user($save){
	   
		if ($save['id'] != ""){
			
			$this->db->where('id', $save['id']);
			$this->db->update('users', $save);

			$id	= $save['id'];
		}
		else{
			
			$this->db->insert('users', $save);
			$id	= $this->db->insert_id();
		}
		return $id;
	}
	
	function get_user($id){
		
		$query = $this->db->get_where('users', array('id'=>$id))->row();
		return $query;
    }
	
	function checkPhone($id, $phone){
		
		if($id == ""){
			$this->db->where('phone', $phone);
			$num = $this->db->count_all_results('users');
		}else{
			$this->db->where('phone', $phone);
			$this->db->where_not_in('id', $id);
			$num = $this->db->count_all_results('users');
		}
		return $num;
	}
	
	function checkEmail($id, $email){
		
		if($id == ""){
			$this->db->where('email', $email);
			$num = $this->db->count_all_results('users');
		}else{
			$this->db->where('email', $email);
			$this->db->where_not_in('id', $id);
			$num = $this->db->count_all_results('users');
		}
		return $num;
	}
	
	function delete_user($id){
		
		return $this->db->where('id', $id)->delete('users');
	}
	
}