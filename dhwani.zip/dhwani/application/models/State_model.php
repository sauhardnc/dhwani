<?php
Class State_model extends CI_Model
{
	function get_states(){
		
		$query = $this->db->order_by('state_name', 'ASC')->get_where('state', array('status' => '1'))->result();
		// echo $this->db->last_query(); die;
		return $query;
    }
	
	function get_menus(){
		
		$query = $this->db->order_by('id', 'ASC')->get_where('menu_master', array('status' => '1'))->result();
		// echo $this->db->last_query(); die;
		return $query;
    }
	
	function save_state($save){
	   
		if ($save['id'] != ""){
			
			$this->db->where('id', $save['id']);
			$this->db->update('state', $save);

			$id	= $save['id'];
		}
		else{
			
			$this->db->insert('state', $save);
			$id	= $this->db->insert_id();
		}
		return $id;
	}
	
	function get_state($id){
		
		$query = $this->db->get_where('state', array('id'=>$id))->row();
		return $query;
    }
	
	function delete_state($id){
		
		return $this->db->where('id', $id)->delete('state');
	}
}