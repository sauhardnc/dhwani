<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function check_permission($role_id, $menu_id, $action = 'view_data'){
	
	$CI = &get_instance();
	$CI->load->model('User_model');
	
	$CI->db->select('*');
	
	if($role_id){
		
		$CI->db->where('role_id', $role_id);
	}
	
	if($menu_id){
		
		$CI->db->where('menu_id', $menu_id);
	}
	
	$CI->db->from('permission');
	
	
	$query = $CI->db->get()->row();
	
	// print_r($query); echo $CI->db->last_query(); 
	// die;
	
	if(!empty($query)){
		
		if($query->$action){
			
			return true;
		
		}else{
		
			return false;
		}
	
	}else{
	
		return true;
	}
}